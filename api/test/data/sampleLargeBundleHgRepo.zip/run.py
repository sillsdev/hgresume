from __future__ import print_function
import random, string, os

filename = "file1"
for x in range(0, 1000):
    print("run %d\n" % x)
    randomtext = ''.join(random.choice(string.lowercase) for i in range(10))
    with open(filename, 'a') as f:
        f.write(randomtext)
    cmd = "hg commit -m \"modified %s\"" % filename
    print(cmd)
    os.system(cmd)
